/**
 * 
 */
package Presentaci�n.Hipoteca;

import javax.swing.JTextArea;
import javax.swing.JTextField;

/** 
 * <!-- begin-UML-doc -->
 * <!-- end-UML-doc -->
 * @author usuario_local
 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
 */
public class cuadroSolicitarHipoteca extends JTextField {
}